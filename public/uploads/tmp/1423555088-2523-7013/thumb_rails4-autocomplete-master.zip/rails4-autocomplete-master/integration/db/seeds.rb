Brand.create(:name => 'Alpha')
Brand.create(:name => 'Gamma')
Brand.create(:name => 'Omega')
