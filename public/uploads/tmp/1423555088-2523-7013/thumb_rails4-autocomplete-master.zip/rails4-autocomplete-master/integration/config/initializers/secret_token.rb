# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Integration::Application.config.secret_token = '6cfc71a180f0482c7f2896f0ce99929ad1c6343a6eb73db8e09f7bae0d93edbcabaf06def9d1e5ce7dabf2dd3a410f878272d2120660f2e49ed0ef431d7cad30'
