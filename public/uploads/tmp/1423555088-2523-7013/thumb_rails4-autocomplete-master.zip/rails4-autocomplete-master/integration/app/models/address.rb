class Address < ActiveRecord::Base
end
