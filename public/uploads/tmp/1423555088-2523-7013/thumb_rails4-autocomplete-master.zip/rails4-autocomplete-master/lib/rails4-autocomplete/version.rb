module Rails4Autocomplete
  VERSION = '1.1.1'
end
